package com.employeePortal.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Data
public class UserProfileDetail {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String firstName;
    private String lastName;
    private String phoneNo;
    private String designation;
    private String department;
    private String projectWorking;
    private Long salary;
    private String OfferLetterPath;

    @JsonIgnore
    @OneToOne(mappedBy = "userProfileDetail", cascade = CascadeType.ALL)
    private User user;
}
