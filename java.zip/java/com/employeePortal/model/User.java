package com.employeePortal.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.engine.internal.Cascade;

import javax.persistence.*;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String username;
    @Column(unique = true)
    private String email;
    private String password;
    private String role;
    @Transient
    private String token;


    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "profile_detail")
    private UserProfileDetail userProfileDetail;


}
