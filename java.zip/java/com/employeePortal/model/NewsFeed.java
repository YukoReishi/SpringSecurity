package com.employeePortal.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Entity
@NoArgsConstructor
@AllArgsConstructor
@Data
public class NewsFeed {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String titles;
    private String description;
    private String filesLocation;

    @OneToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL, targetEntity = NewsComment.class)
    private NewsComment comments;
}
