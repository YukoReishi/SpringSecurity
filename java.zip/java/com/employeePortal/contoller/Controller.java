package com.employeePortal.contoller;

import com.employeePortal.contoller.DAO.SignInDAO;
import com.employeePortal.model.User;
import com.employeePortal.model.UserProfileDetail;
import com.employeePortal.service.AuthenticationServiceImpl;
import com.employeePortal.service.UserServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.Optional;

@CrossOrigin
@RestController
@RequestMapping("User")
public class Controller {

    @Autowired
    private AuthenticationServiceImpl authenticationService;

    @Autowired
    private UserServiceImpl userService;

//    Used By the Admin to register new Employee
    @PostMapping(value = "/signup", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<?> signUp(@RequestParam("json") User user, @RequestParam("file")MultipartFile file) throws IOException {
        userService.addUser(user, file);
        return new ResponseEntity<>(HttpStatus.OK);
    }

//    Used for login by the Employee
    @PostMapping("/login")
    public ResponseEntity<?> singIn(@RequestBody SignInDAO signInDAO){
        return new ResponseEntity<>(authenticationService.signIn(signInDAO), HttpStatus.OK);
    }

//
    @GetMapping("/findByEmailID")
    public ResponseEntity<?> findById (@RequestParam(name = "email") String email){
        return new ResponseEntity<>(userService.findByEmailId(email), HttpStatus.OK) ;
    }

//    Used by Employee and Manager to update their profiles
    @PutMapping("/updateProfile")
    public ResponseEntity<?> updateProfile(@RequestBody UserProfileDetail userProfileDetail, @RequestParam(name = "id") Long id) throws Exception {
        return new ResponseEntity<>(userService.updateProfile(id, userProfileDetail), HttpStatus.OK) ;
    }

    @GetMapping("/searchByName")
    public ResponseEntity<?> searchByName(@RequestParam(name = "firstname") String name){
        return new ResponseEntity<>(userService.searchByName(name), HttpStatus.OK);
    }
}
