package com.employeePortal.contoller;

import com.employeePortal.model.Documents;
import com.employeePortal.service.DocumentsServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;

@CrossOrigin
@RestController
@RequestMapping("Documents")
public class DocumentsController {

    @Autowired
    private DocumentsServiceImpl documentsService;

    @PostMapping(produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> addDocuments(@RequestParam(name = "docname") String docName,
                                          @RequestParam(name = "department") String department,
                                          @RequestParam(name = "uploadedby") String uploadedby,
                                          @RequestParam(name = "status") String status,
                                          @RequestParam(name = "file") MultipartFile file) throws IOException {

        return new ResponseEntity<>(documentsService.addDocuments(docName, department, uploadedby, status, file), HttpStatus.OK);
    }

    @GetMapping(value = "/getFiles", produces = MediaType.APPLICATION_PDF_VALUE)
    public ResponseEntity<?> getFiles(@RequestParam(name = "id") Long id) throws IOException {
        return new ResponseEntity<>(documentsService.getFiles(id), HttpStatus.OK);
    }

    @GetMapping("getDocuments")
    public ResponseEntity<?> viewDocuments(@RequestParam(name = "status") String status){
        return new ResponseEntity<>(documentsService.viewDocuments(status), HttpStatus.OK);
    }

    @PutMapping("verifyDocuments")
    public ResponseEntity<?> verifyDocuments(@RequestParam(name = "id") Long id,
                                             @RequestBody Documents documents) throws Exception {
        return new ResponseEntity<>(documentsService.verifyDocuments(id, documents), HttpStatus.OK);
    }

    @GetMapping("getDocuments/owner")
    public ResponseEntity<?> viewDocumentsByOwner(@RequestParam(name = "uploadedBy") String uploadedBy){
        return new ResponseEntity<>(documentsService.viewDocumentsByOwner(uploadedBy), HttpStatus.OK);
    }
}
