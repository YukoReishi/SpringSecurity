package com.employeePortal.contoller;

import com.employeePortal.model.Offers;
import com.employeePortal.service.OfferServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@CrossOrigin
@RestController
@RequestMapping("/Offers")
public class OffersController {

    @Autowired
    private OfferServiceImpl offerService;

    @PostMapping("/addOffers")
    public ResponseEntity<?> addOffers(@RequestBody Offers offers){
        return new ResponseEntity<>(offerService.addNewOffers(offers), HttpStatus.OK);
    }

    @GetMapping("/viewOffers")
    public ResponseEntity<?> viewOffers(){
        return new ResponseEntity<>(offerService.findOffers(), HttpStatus.OK);
    }

    @GetMapping("/viewOffersByType")
    public ResponseEntity<?> viewOffersByType(@RequestParam(name = "type") String type){
        return new ResponseEntity<>(offerService.findOffersByType(type), HttpStatus.OK);
    }
}
