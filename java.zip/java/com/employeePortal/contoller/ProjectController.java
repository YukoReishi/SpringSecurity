package com.employeePortal.contoller;

import com.employeePortal.service.ProjectServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;

@CrossOrigin
@RestController
@RequestMapping("/Project")
public class ProjectController {

    @Autowired
    private ProjectServiceImpl projectService;

    @PostMapping(value = "/addProject", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> addProject(@RequestParam(name = "projectFile")MultipartFile file,
                                        @RequestParam(name = "projectName") String name,
                                        @RequestParam(name = "projectOwner") String owner,
                                        @RequestParam(name = "projectDescription") String description,
                                        @RequestParam(name = "startDate") String startDate,
                                        @RequestParam(name = "endDate")String endDate) throws IOException {
        return new ResponseEntity<>(projectService.addProject(file, name, owner, description, startDate, endDate), HttpStatus.OK);
    }

    @GetMapping(value = "/getProjectFiles", produces = MediaType.IMAGE_JPEG_VALUE)
    public ResponseEntity<?> getProjectFiles(@RequestParam(name = "id") Long id) throws IOException {
        return new ResponseEntity<>(projectService.getProjectFiles(id), HttpStatus.OK);
    }

    @GetMapping(value = "/getAllProjects")
    public ResponseEntity<?> getAllProjects(){
        return new ResponseEntity<>(projectService.getAllProject(), HttpStatus.OK);
    }

    @GetMapping(value = "/getProjectsByOwner")
    public ResponseEntity<?> getByOwner(@RequestParam(name = "owner") String owner){
        return new ResponseEntity<>(projectService.getByOwner(owner), HttpStatus.OK);
    }
}
