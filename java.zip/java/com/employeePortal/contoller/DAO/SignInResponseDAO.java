package com.employeePortal.contoller.DAO;


import com.employeePortal.model.User;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Optional;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class SignInResponseDAO {

    private Long id;
    private String username;
    private String email;
    private String role;
    private String token;
    private Optional<User> user;
}
