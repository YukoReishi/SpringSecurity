package com.employeePortal.contoller.DAO;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SignInDAO {

    private String email;
    private String password;

}
