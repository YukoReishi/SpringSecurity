package com.employeePortal.contoller.DAO;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SearchUserResponseDAO {

    private Long id;
    private String firstName;
    private String lastName;
    private String phoneNo;
    private String designation;
    private String department;
    private String projectWorking;
}
