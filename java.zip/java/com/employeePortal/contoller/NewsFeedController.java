package com.employeePortal.contoller;

import com.employeePortal.service.NewsFeedServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.net.MalformedURLException;

@CrossOrigin
@RestController
@RequestMapping("/NewsFeed")
public class NewsFeedController {

    @Autowired
    private NewsFeedServiceImpl newsFeedService;

    @PostMapping(value = "/addNews", produces = MediaType.APPLICATION_JSON_VALUE)
        public ResponseEntity<?> addNews(@RequestParam(name = "file") MultipartFile file,
                                        @RequestParam(name = "title") String title,
                                        @RequestParam(name = "description") String description) throws IOException {
            return new ResponseEntity<>(newsFeedService.addNewsFeed(file, title, description), HttpStatus.OK);
    }

    @GetMapping(value = "/getFiles", produces = MediaType.IMAGE_JPEG_VALUE)
    public ResponseEntity<?> getFiles(@RequestParam(name = "id") Long id) throws IOException {
        return new ResponseEntity<>(newsFeedService.getFiles(id), HttpStatus.OK);
    }

    @GetMapping("/getNewsFeed")
    public ResponseEntity<?> getNews(){
        return new ResponseEntity<>(newsFeedService.getNewsFeed(), HttpStatus.OK);
    }





























//    @PostMapping(value = "/upload", produces = MediaType.APPLICATION_JSON_VALUE)
//    public ResponseEntity<?> uploadFiles(@RequestParam(name = "files")MultipartFile file,
//                                         @RequestParam(name = "title") String title,
//                                         @RequestParam(name = "description") String description
//                                         ) throws IOException {
//        return new ResponseEntity<>(newsFeedService.uploadFile(file, title, description), HttpStatus.OK);
//    }
//
//
//
//    @GetMapping("/getfiles")
//    public ResponseEntity<?> getFiles(@RequestParam(name = "filepath") Long path) throws MalformedURLException {
//        return new ResponseEntity<>(newsFeedService.getNewsFile(path), HttpStatus.OK);
//    }
}
