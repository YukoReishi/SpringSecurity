package com.employeePortal.service;

import com.employeePortal.model.NewsFeed;
import com.employeePortal.repository.NewsCommentRepository;
import com.employeePortal.repository.NewsFeedRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.Optional;

@Service
public class NewsFeedServiceImpl {

    public final String FILE_PATH = "D:/Java Projects/Project2/Uploaded Files/";
    @Autowired
    private NewsFeedRepository newsFeedRepository;

    @Autowired
    private NewsCommentRepository commentRepository;

    public NewsFeed addNewsFeed(MultipartFile file, String title, String description) throws IOException {
        String filePath = FILE_PATH + file.getOriginalFilename();

        NewsFeed newsFeed = new NewsFeed();
        newsFeed.setTitles(title);
        newsFeed.setDescription(description);
        newsFeed.setFilesLocation(filePath);

        file.transferTo(new File(filePath));

        return newsFeedRepository.save(newsFeed);
    }

    public List<NewsFeed> getNewsFeed(){
        return newsFeedRepository.findAll();
    }

    public byte[] getFiles(Long id) throws IOException {
        Optional<NewsFeed> newsData= newsFeedRepository.findById(id);
        String filePath = newsData.get().getFilesLocation();
        return Files.readAllBytes(new File(filePath).toPath());
    }
}
