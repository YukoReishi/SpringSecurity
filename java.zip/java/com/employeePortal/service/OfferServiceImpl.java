package com.employeePortal.service;

import com.employeePortal.model.Offers;
import com.employeePortal.repository.OffersRepository;
import com.employeePortal.repository.UserProfileDetailRepository;
import com.twilio.Twilio;
import com.twilio.http.TwilioRestClient;
import com.twilio.rest.api.v2010.account.Message;
import com.twilio.type.PhoneNumber;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class OfferServiceImpl {

    @Autowired
    private OffersRepository offersRepository;

    @Autowired
    private UserProfileDetailRepository userProfileDetailRepository;




    private static final String ACCOUNT_SID = "AC583080825da88019a16e75ea28433dab";
    public static final String AUTH_TOKEN = "399ab35674780dd92f26002a5775d733";

    //    Adding New Offers(Used by Admins Only)
    public Offers addNewOffers(Offers offers){
        Twilio.init(ACCOUNT_SID, AUTH_TOKEN);
        List<String> listOfPhoneNumber = userProfileDetailRepository.allPhoneNo();
        String description = offers.getDescription();

        String expiry = offers.getValidity();

//        for(String number : listOfPhoneNumber){
            Message.creator(new PhoneNumber("+919560608586"),
                    new PhoneNumber("+17375308393"),
                    "New Offers has been added. " + description + " " + expiry + ". Hurry Up...Grab it before expiry.").create();
//        }
        return offersRepository.save(offers);
    }

//    Viewing all the Offers(Visible to all)
    public List<Offers> findOffers(){
        return offersRepository.findAll();
    }

    public List<Offers> findOffersByType(String type){
        return offersRepository.findByType(type);
    }
}
