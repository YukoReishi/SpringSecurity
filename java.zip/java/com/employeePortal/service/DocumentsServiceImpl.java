package com.employeePortal.service;

import com.employeePortal.model.Documents;
import com.employeePortal.model.NewsFeed;
import com.employeePortal.repository.DocumentsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.List;
import java.util.Optional;

@Service
public class DocumentsServiceImpl {

    private final String DOCUMENT_LOCATION = "D:/Java Projects/Project2/Uploaded Files/Document/";
    @Autowired
    private DocumentsRepository documentsRepository;

    public Documents addDocuments(String docName, String department,
                                  String uploadedBy, String status,
                                  MultipartFile file) throws IOException {

        String filePath = DOCUMENT_LOCATION + file.getOriginalFilename();
        file.transferTo(new File(filePath));

        Documents documents = new Documents();
        documents.setDocName(docName);
        documents.setDepartment(department);
        documents.setUploadedBy(uploadedBy);
        documents.setStatus(status);
        documents.setFilePath(filePath);

        return documentsRepository.save(documents);

    }

    public List<Documents> viewDocuments(String status){
        return documentsRepository.findByStatus(status);
    }

    public Documents verifyDocuments(Long id, Documents documents) throws Exception {
        Documents documents1 = documentsRepository.findById(id).orElseThrow(() -> new Exception());

        documents1.setDocName(documents.getDocName());
        documents1.setDepartment(documents.getDepartment());
        documents1.setUploadedBy(documents.getUploadedBy());
        documents1.setStatus(documents.getStatus());
        documents1.setFilePath(documents.getFilePath());

        return documentsRepository.save(documents1);
    }

    public List<Documents> viewDocumentsByOwner(String uploadedBy) {
        return documentsRepository.findByUploadedBy(uploadedBy);
    }

    public byte[] getFiles(Long id) throws IOException {
        Optional<Documents> documents= documentsRepository.findById(id);
        String filePath = documents.get().getFilePath();
        return Files.readAllBytes(new File(filePath).toPath());
    }
}
