package com.employeePortal.service;

import com.employeePortal.model.NewsFeed;
import com.employeePortal.model.Project;
import com.employeePortal.repository.ProjectRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.List;
import java.util.Optional;

@Service
public class ProjectServiceImpl {

    private final String DOCUMENT_PATH = "D:/Java Projects/Project2/Uploaded Files/ProjectFiles/";

    @Autowired
    private ProjectRepository projectRepository;

    public Project addProject(MultipartFile file, String projectName,
                              String projectLead, String projectDescription,
                              String startDate, String estimatedEndDate) throws IOException {

        String filePath = DOCUMENT_PATH + file.getOriginalFilename();

        file.transferTo(new File(filePath));

        Project project = Project.builder()
                .projectName(projectName)
                .projectLead(projectLead)
                .projectDescription(projectDescription)
                .startDate(startDate)
                .estimatedEndDate(estimatedEndDate)
                .projectDocumentPath(filePath)
                .build();

        return projectRepository.save(project);
    }

    public List<Project> getAllProject(){
        return projectRepository.findAll();
    }

    public List<Project> getByOwner(String owner){
        return projectRepository.findByProjectLead(owner);
    }

    public byte[] getProjectFiles(Long id) throws IOException {
        Optional<Project> project= projectRepository.findById(id);
        String filePath = project.get().getProjectDocumentPath();
        return Files.readAllBytes(new File(filePath).toPath());
    }


}
