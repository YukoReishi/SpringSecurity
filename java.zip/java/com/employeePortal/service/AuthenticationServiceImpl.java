package com.employeePortal.service;

import com.employeePortal.JWTUtils.JwtUtils;
import com.employeePortal.Security.UserDetail;
import com.employeePortal.contoller.DAO.SignInDAO;
import com.employeePortal.contoller.DAO.SignInResponseDAO;
import com.employeePortal.model.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class AuthenticationServiceImpl {

    @Autowired
    private JwtUtils jwtUtils;

    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    private UserServiceImpl userService;

    public SignInResponseDAO signIn (SignInDAO signInRequest) {
        Authentication authentication = authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(signInRequest.getEmail(), signInRequest.getPassword()));

        UserDetail userDetail = (UserDetail) authentication.getPrincipal();

        String jwt = jwtUtils.generateJWT(userDetail);

        System.out.println(jwt);

        SignInResponseDAO user = new SignInResponseDAO();



        if (authentication.isAuthenticated()) {
            Optional<User> users = userService.findByEmailId(signInRequest.getEmail());
            user.setId(userDetail.getId());
            user.setUsername(userDetail.getUsername());
            user.setEmail(userDetail.getEmail());
            user.setRole(userDetail.getAuthorities().toString());
            user.setToken(jwt);
            user.setUser(users);
        }

        return user;
    }
}
