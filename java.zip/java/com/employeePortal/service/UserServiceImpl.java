package com.employeePortal.service;

import com.employeePortal.contoller.DAO.SearchUserResponseDAO;
import com.employeePortal.model.User;
import com.employeePortal.model.UserProfileDetail;
import com.employeePortal.repository.UserProfileDetailRepository;
import com.employeePortal.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.config.ConfigDataResourceNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import org.w3c.dom.stylesheets.LinkStyle;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Optional;

@Service
public class UserServiceImpl {

    private final String DOCUMENT_LOCATION = "D:/Java Projects/Project2/Uploaded Files/UserDocuments/";

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private UserProfileDetailRepository userProfileDetailRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;


//    Adding New Employee (Used by Admin)
    public void addUser(User user, MultipartFile file) throws IOException {
        String filePath = DOCUMENT_LOCATION + file.getOriginalFilename();
        file.transferTo(new File(filePath));
        user.setPassword(passwordEncoder.encode(user.getPassword()));
        userRepository.save(user);

        UserProfileDetail userProfileDetail1 = userRepository.findByEmail(user.getEmail()).get().getUserProfileDetail();
        userProfileDetail1.setOfferLetterPath(filePath);
        userProfileDetailRepository.save(userProfileDetail1);
    }

//    Updating Profile (Used By Employee and Manager)
    public UserProfileDetail updateProfile(Long id, UserProfileDetail userProfileDetail) throws Exception{
        UserProfileDetail userProfileDetail1 = userProfileDetailRepository.findById(id)
                .orElseThrow(() -> new Exception());

        userProfileDetail1.setFirstName(userProfileDetail.getFirstName());
        userProfileDetail1.setLastName(userProfileDetail.getLastName());
        userProfileDetail1.setDesignation(userProfileDetail.getDesignation());
        userProfileDetail1.setDepartment(userProfileDetail.getDepartment());
        userProfileDetail1.setPhoneNo(userProfileDetail.getPhoneNo());
        userProfileDetail1.setProjectWorking(userProfileDetail.getProjectWorking());
        userProfileDetail1.setSalary(userProfileDetail.getSalary());

        userProfileDetailRepository.save(userProfileDetail1);

        return userProfileDetail1;
    }

//    Searching User Details by EmailId (Also used by Sign In Authorization)
    public Optional<User> findByEmailId(String email){
        return userRepository.findByEmail(email);
    }

    public List<UserProfileDetail> searchByName(String name){
        return userProfileDetailRepository.findByFirstName(name);
    }























//    Searching UserDetailProfile using Name (Used by all type of Employee)
//    public void searchByName(String name){
//        List<UserProfileDetail> userProfileDetail1 =  userProfileDetailRepository.findByFirstName(name);
//        List<User> user = userRepository.findById(userProfileDetail1.stream().forEach((response) -> {
//            System.out.println(response.getUser());
//        }).;



}
