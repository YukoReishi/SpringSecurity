package com.employeePortal.Security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

@Configuration
@EnableWebSecurity
public class WebSecurityConfig {

    @Autowired
    private UserDetailService userDetailService;

    @Bean
    public PasswordEncoder passwordEncoder(){
        return new BCryptPasswordEncoder();
    }

    @Bean
    public JwtFilter jwtFilter(){
        return new JwtFilter();
    }

    @Bean
    public DaoAuthenticationProvider authenticationProvider(){
        DaoAuthenticationProvider authenticationProvider = new DaoAuthenticationProvider();
        authenticationProvider.setUserDetailsService(userDetailService);
        authenticationProvider.setPasswordEncoder(passwordEncoder());
        return authenticationProvider;
    }

    @Bean
    public AuthenticationManager authenticationManager(AuthenticationConfiguration authConfiguration) throws Exception {
        return authConfiguration.getAuthenticationManager();
    }

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception{
        http.cors().and().csrf().disable()
                .exceptionHandling()
                .and()
                .sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS)
                .and()
                .authorizeRequests()
                .antMatchers("/User/login").permitAll()
                .antMatchers("/User/signup").permitAll()
                .antMatchers("/User/updateProfile").hasAnyAuthority("EMPLOYEE", "MANAGER")
                .antMatchers("/User/searchByName").hasAnyAuthority("ADMIN", "MANAGER", "EMPLOYEE")
                .antMatchers("/Offers/addOffers").hasAnyAuthority("ADMIN")
                .antMatchers("/Offers/viewOffers").hasAnyAuthority("ADMIN", "MANAGER", "EMPLOYEE")
                .antMatchers("/Offers/viewOffersByType").hasAnyAuthority("ADMIN", "MANAGER", "EMPLOYEE")
                .antMatchers("/NewsFeed/addNews").hasAuthority("ADMIN")
                .antMatchers("/NewsFeed/getNewsFeed").hasAnyAuthority("ADMIN","MANAGER", "EMPLOYEE")
                .antMatchers("/NewsFeed/getFiles").permitAll()
                .antMatchers("/Project/*").permitAll()
                .antMatchers("/Documents/*").permitAll()
//                .antMatchers("/User/findByEmailID").permitAll()

                .anyRequest().authenticated();

        http.authenticationProvider(authenticationProvider());

        http.addFilterBefore(jwtFilter(), UsernamePasswordAuthenticationFilter.class);

        return http.build();
    }
}
