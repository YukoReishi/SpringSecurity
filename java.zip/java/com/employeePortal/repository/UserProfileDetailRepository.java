package com.employeePortal.repository;

import com.employeePortal.model.UserProfileDetail;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface UserProfileDetailRepository extends JpaRepository<UserProfileDetail, Long> {

    List<UserProfileDetail> findByFirstName(String name);

    @Query(nativeQuery = true, value = "SELECT phone_no FROM user_profile_detail")
    List<String> allPhoneNo();
}
