package com.employeePortal.repository;

import com.employeePortal.model.Documents;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface DocumentsRepository extends JpaRepository<Documents, Long> {

    List<Documents> findByStatus(String status);

    List<Documents> findByUploadedBy(String uploadedBy);
}
