package com.employeePortal.JWTUtils;

import com.employeePortal.Security.UserDetail;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.security.Keys;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import javax.servlet.http.HttpServletRequest;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Date;
import java.util.Set;
import java.util.stream.Collectors;

@Component
public class JwtUtils {

    private String SECRET_KEY = "s3cr3ts3cr3ts3cr3ts3cr3ts3cr3ts3cr3ts3cr3ts3cr3ts3cr3ts3cr3ts3cr3ts3cr3t";

    private int JwtExpirationInMS = 12 * 60 * 60 * 60;

    public static final String AUTH_HEADER = "authorization";

    public static final String AUTH_TOKEN_PREFIX = "Bearer" + " ";

    public String generateJWT (UserDetail auth){

        String authorities = auth.getAuthorities().stream()
                .map(GrantedAuthority::getAuthority)
                .collect(Collectors.joining(","));

        Key key = Keys.hmacShaKeyFor(SECRET_KEY.getBytes(StandardCharsets.UTF_8));

        return Jwts.builder()
                .setSubject(auth.getUsername())
                .claim("roles", authorities)
                .claim("userId", auth.getId())
                .setExpiration(new Date(System.currentTimeMillis() + JwtExpirationInMS))
                .signWith(key, SignatureAlgorithm.HS512)
                .compact();
    }

    public static String extractAuthTokenFromRequest(HttpServletRequest request){

        String bearerToken = request.getHeader(AUTH_HEADER);

        if (StringUtils.hasLength(bearerToken) && bearerToken.startsWith(AUTH_TOKEN_PREFIX)){
            return bearerToken.substring(7);
        }
        return null;
    }

    public boolean isValidToken(HttpServletRequest request){
        Claims claims = extractClaim(request);

        if (claims == null){
            return false;
        }
        if (claims.getExpiration().before(new Date())){
            return false;
        }
        return true;
    }

    private Claims extractClaim(HttpServletRequest request){
        String token = extractAuthTokenFromRequest(request);

        if (token == null){
            return null;
        }
        Key key = Keys.hmacShaKeyFor(SECRET_KEY.getBytes(StandardCharsets.UTF_8));

        return Jwts.parserBuilder()
                .setSigningKey(key)
                .build()
                .parseClaimsJws(token)
                .getBody();
    }

    public Authentication getAuthentication(HttpServletRequest request){
        Claims claims = extractClaim(request);

        if (claims == null){
            return null;
        }

        String username = claims.getSubject();
        Long userId = claims.get("userId", Long.class);

        String role = claims.get("roles", String.class);
        SimpleGrantedAuthority simpleGrantedAuthority = new SimpleGrantedAuthority(role);

        Set<GrantedAuthority> authorities = Set.of(simpleGrantedAuthority);

//        Set<GrantedAuthority> authorities = Set.of(claims.get("roles", GrantedAuthority.class));

        UserDetails userDetails = UserDetail.builder()
                .username(username)
                .id(userId)
                .authorities(authorities)
                .build();

        return new UsernamePasswordAuthenticationToken(userDetails, null, authorities);
    }
}
